# `@studio/core` — specification

This document is the package. Code that disagrees with it is wrong; if the spec needs to change, change the spec first. Every section maps to a contract test in `packages/core/test/` (see §9). `@studio` is a placeholder scope.

**What it is:** the shared runtime for every client site the pipeline builds — database schema and migrations, the route handlers a site needs (auth, uploads, donations, admin API), the public-site content reads, and the admin UI. One package, pinned by version in each client repo, upgraded by bumping the pin.

**What it is for:** small organisations (churches, nonprofits, small businesses) whose site has a handful of posts, events, a gallery, a contact form and a donate button, edited by one or two non-technical people.

---

## 1. Public API surface

The package has **five entry points**, enforced by the `exports` map in `package.json`. Nothing else is importable; deep imports fail at resolve time. The package is a library over `Request`/`Response`: nothing outside `./next` imports a framework (test 14 mounts it on Node's `http`), and `LIFTING.md` is the recipe for putting a new frontend on it.

| Entry | Runtime | Exports |
|---|---|---|
| `@studio/core` | server | `schema`, `createDb`, `env` + `parseEnv`/`envKeys`/`requiredEnvKeys`, `createSite`, `mediaUrl`, `defineCollections`, `defaultCollections`, `pickCollections`, `occurrences`, `nextOccurrence`, `icsFor`, `RichText`, `docFromText`, `docToText`, `EMPTY_DOC`, `sendMail`, `memoryMailer`, types |
| `@studio/core/next` | server | `nextCache()` — the Next.js `Cache` adapter. The only code in the package that imports `next`. |
| `@studio/core/admin` | client | the headless admin: `createApi`, a hook per screen (§1.3), the rich-text editor hook, the pure form rules (`formBody`, `saveOutcome`, `duplicateBody`, `slugify`) and the display helpers (`fmtDate`, `formatCell`, `labelFor`, `titleOf`, `previewOf`, `detailsOf`, `publishState`, `repeatLabel`, `rowUrl`, `exportCsv`, `isImageRow`, `isDateProp`), plus the repeat picker's `repeatToRule`/`ruleToRepeat`/`REPEAT_OPTIONS`. The screens live with the site (`template/components/admin`, shadcn/ui) and are synced by upgrades. |
| `@studio/core/schema` | any | the Drizzle schema module alone (for `drizzle.config.ts`) |
| `@studio/core/migrations` | fs path | the shipped SQL migrations folder (for `db:migrate`) |

### 1.1 `@studio/core`

```ts
import type { NextRequest } from 'next/server'

export * as schema from './db/schema'
export type Db = NeonHttpDatabase<typeof schema>
export function createDb(databaseUrl: string): Db          // Neon HTTP driver for *.neon.tech URLs; node-postgres for anything else (local dev, CI, smoke)

export const env: Env                                       // lazy: parsed on first property access; throws listing every missing var (§7)
export function parseEnv(source: Record<string, string | undefined>): Env
export type Env

export function createSite<M>(opts: { db: Db; env: Env; collections: Collections<M>; cache?: Cache; deps?: HandlerDeps }): {
  handle(req: Request, path: string[]): Promise<Response>   // framework-free; `path` = segments after the mount point
  handlers: { GET; POST; PATCH; DELETE }                    // the same thing shaped for Next's App Router
  content: Content<M>                                       // typed public reads, below
  collections: Collections<M>                               // `.meta` is what the admin screens render
}

interface Cache {                                           // the one framework seam; default `noCache` reads through
  wrap<T>(fn, key: string[], opts: { tags: string[]; revalidate: number }): () => Promise<T>
  revalidate(tags: Iterable<string>): void
}

interface Content<M> {                                      // derived from the collections, no per-table code
  list(name, { limit?, filter?, where? }): Promise<Doc[]>    // published rows past their date, newest `dateField` first, with `cover`
  get(name, slugOrId): Promise<Doc | null>                   // by slug when the collection has one
  mediaUrl(key): string                                      // R2 object or repo file
}
```

`filter` names one of the collection's declared `reads.filters` (events: `upcoming`); `where` is equality on visible
columns (media: `{ collection }`). The "published" rule is derived: a `status` select with draft/published, plus
`publishedAt <= now()` when the column exists; `reads.filter` adds a collection's own predicate (media: confirmed).

```ts
### 1.2 Route table served by `handle`

All paths are relative to wherever the template mounts the catch-all (the template mounts it at `/api/site`).

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `auth/request` | none (rate-limited) | body `{ email }`; if in `ADMIN_EMAILS`, emails a magic link. Always 200 (no email enumeration). |
| GET | `auth/verify?token=` | none | consumes token, sets session cookie, redirects to `/admin`. |
| POST | `auth/logout` | session | deletes session row, clears cookie. |
| GET | `auth/me` | none | `{ email }` when signed in, `{ email: null }` otherwise — always 200, so an unauthenticated admin load logs no console error. Used by `useSession` on load. |
| POST | `admin/[collection]/[id]/read` | session | sets `read_at` on a row that has it (submissions). The only write allowed on a read-only collection. |
| POST | `presign` | session | body `{ filename, mime, sizeBytes, width?, height?, collection? }` → `{ uploadUrl, key, mediaId }`. Creates the `media` row up front (§2.1) so an abandoned upload is a row without an object; a nightly `content` call is not needed — the admin hides rows whose object never arrived (`confirmed_at null`). |
| POST | `presign/confirm` | session | body `{ mediaId }` → sets `confirmed_at`. |
| POST | `stripe/checkout` | none | body `{ amountCents, currency?, donorName?, donorEmail? }` → `{ url }`. 503 `{ error: 'donations_not_configured' }` when Stripe env is absent. |
| POST | `stripe/webhook` | Stripe signature | `checkout.session.completed` → upsert `donations` by `stripe_checkout_session_id`; idempotent. |
| POST | `forms/[form]` | none (rate-limited) | `form ∈ {contact, volunteer, newsletter}`; body is the payload; inserts `submissions`, emails `EMAIL_REPLY_TO`. Honeypot field `website` must be empty. |
| GET | `admin/[collection]` | session | list; query `?page&sort&dir&q`; `?unread=1` on inbox collections, whose responses also carry `unread` (count). |
| POST | `admin/[collection]` | session | create; validated by the collection's zod schema; revalidates tags. |
| GET | `admin/[collection]/[id]` | session | one row. |
| PATCH | `admin/[collection]/[id]` | session | update; validated; revalidates tags. |
| DELETE | `admin/[collection]/[id]` | session | delete; revalidates tags. Refused for `readOnly` collections. |

Unknown path → 404 JSON. Every error response is `{ error: string, issues?: ZodIssue[] }`.

### 1.3 Where the template touches core

Exactly three files in a client repo import from `@studio/core*`:

1. `lib/core.ts` — `export const core = createSite({ db, env, collections, cache: nextCache() })`; `app/api/site/[...path]/route.ts` is `export const { GET, POST, PATCH, DELETE } = core.handlers`
2. `app/admin/[[...path]]/page.tsx` — `<Admin collections={collections.meta} path=… />` from the site's `components/admin`, which renders the hooks from `@studio/core/admin` with shadcn/ui; the site and the admin share one token vocabulary (shadcn/ui's, `design/tokens.css`); `app/admin/admin.css` pins the neutral palette while the admin is mounted (`body:has(.admin)`, so portals get it too)
3. `lib/collections.ts` — `export const collections = defineCollections({ … })`

Everything else in the template (sections, pages, seed script) imports `content`, `RichText`, `createDb`, `env`, `schema` from `@studio/core` only. The template's ESLint config forbids any other `@studio/core/*` specifier. A core test asserts the `exports` map has exactly the five keys above and that `import('@studio/core/db/schema')` (or any internal path) fails to resolve.

---

### 1.3 Hooks in `@studio/core/admin` — a screen each

A frontend renders these; the behaviour, and the tests, live here. All take the `Api` from `createApi({ base })`.

| Hook | Screen | Returns |
|---|---|---|
| `useSession(api)` | shell | `{ user: 'loading' \| null \| { email }, signOut }` |
| `useLogin(api)` | sign-in | `{ state: idle \| busy \| sent \| rate_limited \| error, request(email) }` |
| `useAdminRouter(basePath, initial, onBlocked)` | shell | `{ path, go(segs), href(segs), setDirty }` — in-app navigation via `pushState`; `go` and the Back button refuse while dirty and call `onBlocked(proceed)` |
| `useUnread(api, collections)` | nav badges | `{ unread: { [name]: n }, refresh }` for inbox collections |
| `useOverview(api, collections, perPage?)` | home | `{ [name]: { rows, total } }` — the latest few rows of everything |
| `useRows(api, meta, perPage)` | list | `{ rows, total, page, setPage, pages, q, search, sort, toggleSort, reload, error }` |
| `useUploads(api, meta)` | grid | `{ run(files) → { ok, failed }, progress, label, singular }` |
| `useAltText(api, meta, row)` | grid tile | `{ alt, setAlt, save, saved, stored, error }` |
| `useMediaPicker(api, kind)` | picker | `{ items, upload(file, alt?), busy, error }` |
| `useRecord(api, meta, id, onRead?)` | message | `{ row, error }` — opening an inbox row marks it read |
| `useSingletonId(api, meta)` | settings | `{ id: undefined (looking) \| null (none yet) \| string, error }` |
| `useRecordForm(api, meta, id, opts)` | form | `{ row, set(k, v), errors, busy, dirty, later, setLater, fields: { main, slugKeys, hasWhen }, publish: { state, at, liveUrl }, save(status?), duplicate, remove, confirmDelete }`; `opts.onSaved({ row, outcome, at, url }, created)` — outcomes are `published \| unpublished \| scheduled \| draft \| saved`; the view words them |
| `useRichTextEditor({ value, onChange, mediaBaseUrl })` | editor | a Tiptap editor over the fixed node set; drive it with `editorActions(editor)` |

Hooks return states and dates, never sentences: what to say to the user is the screen's job, so a lifted admin can word (or translate) it.

## 2. Schema

Drizzle, Postgres (Neon). Conventions for **every** table:

- `id uuid primary key default gen_random_uuid()`
- `created_at timestamptz not null default now()`
- `updated_at timestamptz not null default now()` with `.$onUpdate(() => new Date())` — Postgres will not bump it on its own.
- Status columns are `text` with a `check` constraint, **not** Postgres enums (enums make migrations painful).
- Slugs: `text not null unique`, lowercase `[a-z0-9-]+`, validated in zod, generated from the title by the admin's `slug` field type.

### 2.1 Tables

**`media`** — one row per uploaded object.

| column | type | notes |
|---|---|---|
| `key` | text unique not null | R2 object key: `sites/<slug>/<uuid>-<safe-filename>`. `R2_PREFIX` is `sites/<slug>`. |
| `filename` | text not null | original name, for the admin |
| `mime` | text not null | allowed: `image/jpeg`, `image/png`, `image/webp`, `image/avif`, `image/gif`, `image/svg+xml`, `application/pdf` |
| `size_bytes` | int not null | ≤ 25 MB, enforced at presign |
| `width`, `height` | int null | images only; measured **in the browser** before upload (`createImageBitmap`) and sent at presign. `next/image` needs them. |
| `alt` | text not null default '' | admin nags when empty; `check-site` blocks on empty alt for images used in pages |
| `collection` | text null | **a gallery is the set of media sharing a `collection` value**. No join table. `null` = unfiled. |
| `sort` | int not null default 0 | ordering within a collection |
| `confirmed_at` | timestamptz null | set by `presign/confirm`; rows with `null` older than 1h are invisible in the picker and eligible for cleanup |

Index `(collection, sort)`.

**`posts`**

| column | type | notes |
|---|---|---|
| `slug` | text unique not null | |
| `title` | text not null | |
| `excerpt` | text null | plain text, ≤ 300 chars |
| `body` | jsonb not null | **Tiptap/ProseMirror JSON document** (§5). Never HTML. |
| `cover_media_id` | uuid null → `media.id` on delete set null | |
| `status` | text not null default 'draft' | check `in ('draft','published')` |
| `published_at` | timestamptz null | set on first publish if null; editable |

Index `(status, published_at desc)`. Public read predicate: `status = 'published' and published_at <= now()`.

**`events`**

| column | type | notes |
|---|---|---|
| `slug` | text unique not null | |
| `title` | text not null | |
| `description` | jsonb not null | Tiptap JSON |
| `starts_at` | timestamptz not null | absolute instant |
| `ends_at` | timestamptz null | |
| `timezone` | text not null | IANA name (`America/Denver`). Display formats `starts_at` in this zone; without it a 7 pm service renders as 01:00 for a European CDN node. Default from `brief.json`. |
| `location` | text null | |
| `url` | text null | external link (tickets, livestream) |
| `cover_media_id` | uuid null → `media.id` on delete set null | |
| `status` | text not null default 'draft' | check `in ('draft','published')` |

Index `(starts_at)`. `category text null`, `cost text null`, `recurrence text null` (an RFC 5545 RRULE counted from `starts_at`; the row is the master, occurrences are computed on read by `occurrences()` / `nextOccurrence()` with `rrule`, never stored), `registration boolean` (a sign-up form on the event page; sign-ups are `register` submissions carrying `eventId`, `eventTitle`, `guests`). `icsFor()` writes one occurrence as an iCalendar file for "Add to calendar"; the template serves it at `/events/<slug>/calendar`.

**`submissions`** — every public form post.

| column | type | notes |
|---|---|---|
| `form` | text not null | check `in ('contact','volunteer','newsletter')`. Closed set; new forms are a core release. |
| `payload` | jsonb not null | the posted fields, validated per form by a zod schema in core (§2.2) |
| `email` | text null | copied out of `payload` for reply-to and list display |
| `read_at` | timestamptz null | admin "mark read" |

Index `(form, created_at desc)`.

**`donations`** — mirror of Stripe Checkout, one-time only.

| column | type | notes |
|---|---|---|
| `stripe_checkout_session_id` | text unique not null | idempotency key for the webhook |
| `stripe_payment_intent_id` | text null | |
| `amount_cents` | int not null | |
| `currency` | text not null default 'usd' | |
| `donor_name` | text null | |
| `donor_email` | text null | |
| `status` | text not null default 'pending' | check `in ('pending','paid','refunded')` |

**`magic_links`**

| column | type | notes |
|---|---|---|
| `email` | text not null | |
| `token_hash` | text unique not null | sha256 of the 32-byte random token; the raw token exists only in the email |
| `expires_at` | timestamptz not null | 15 minutes |
| `used_at` | timestamptz null | single use |

**`sessions`**

| column | type | notes |
|---|---|---|
| `email` | text not null | |
| `expires_at` | timestamptz not null | 30 days, sliding |

Cookie `studio_session` = `<session id>.<HMAC-SHA256(session id, AUTH_SECRET)>` via `jose` (HS256 JWT with `sid` claim), `HttpOnly; Secure; SameSite=Lax; Path=/`. The server-side row exists so a session can be revoked (handoff, lost laptop) by deleting it.

**`rate_limits`** (internal) — `key text unique`, `count int`, `window_start timestamptz`. Fixed-window counters for the magic-link and form limits, kept in Postgres so they hold across serverless instances. Not a collection.

**There is no `users` table.** `ADMIN_EMAILS` (comma-separated) is the allowlist and the only role. `requireSession` re-checks it on every request, so removing an address revokes a live session immediately (the row is deleted). Changing it is a Vercel env change + redeploy (`pnpm set-admins`).

### 2.2 Form payload schemas (closed set)

```ts
contact:    { name: string(1..120), email: email, message: string(1..4000), phone?: string(..40) }
volunteer:  { name, email, phone?, interests: string(..500), availability?: string(..500) }
newsletter: { email, name?: string(..120) }
```
Every form also accepts and requires-empty a honeypot field `website`. Each is rate-limited per IP (10 / hour).

### 2.3 Relations

`posts.cover_media_id → media.id`, `events.cover_media_id → media.id` (both `on delete set null`). That is the entire relation graph.

---

## 3. Migrations & upgrades

- Core ships SQL migrations generated by `drizzle-kit generate` against `src/db/schema.ts`, committed under `packages/core/migrations/` and published in the package (`files` includes `migrations`). The `./migrations` export resolves to that folder.
- A client site runs `pnpm db:migrate` = `drizzle-orm`'s `migrate()` with `migrationsFolder` = the exported folder, against **`DATABASE_URL_UNPOOLED`** (the migrator takes an advisory lock inside a transaction, which does not survive PgBouncer transaction pooling). Runtime queries use the pooled `DATABASE_URL`.
- It runs at provisioning and as the Vercel build command prefix (`pnpm db:migrate && next build`). Idempotent; a no-op when up to date. `drizzle-kit push` is never used against a client database.
- **Compatibility rule:** every core release's migrations must be safe to apply while the *previous* release's runtime is still serving (Vercel builds before it swaps). Therefore: add columns nullable or with defaults; never rename or drop in the same release that stops writing to a column (expand → release → contract in the next release); never change a column type in place.
- `scripts/release-core.sh` refuses to publish if `drizzle-kit check` reports drift or an ungenerated migration.
- **Upgrade a client:** `pnpm upgrade-client <slug> [version]` bumps the `@studio/core` pin in the client repo, commits, pushes → Vercel migrates and deploys. `pnpm upgrade-all` loops. The oldest core version still deployed on any client is the "oldest supported version"; CI migrates a fresh database from that version's migrations forward and asserts the result matches introspection of the current schema.

---

## 4. Revalidation

Public content pages are statically rendered and revalidated by **cache tag**.

| Read | Tags |
|---|---|
| `content.list(name, …)` | `<name>` |
| `content.get(name, slug)` | `<name>`, `<name>:<slug>` |

- `content.*` wraps each query with the injected `Cache` (`@studio/core/next` uses `unstable_cache(fn, key, { tags, revalidate })`). `next` is an optional peer dependency; core's main entry never imports it.
- Every admin write (`POST`/`PATCH`/`DELETE admin/*`, `presign/confirm`) calls `revalidateTag(tag, { expire: 0 })` — immediate expiry, the editor expects to see their change — for the collection's declared tags plus the row-level tag (`post:<slug>` — old and new slug on rename). Tags are a convention, not configuration: a write to a row revalidates its collection's name, `<collection>:<slug>` when it has a slug (old and new on rename), and every collection whose table has a foreign key to this one (`dependents`, derived in `defineCollections` — so editing a photo refreshes the posts and events that use it as a cover). Reads declare their own collection tag only. The single call site is the `Cache` adapter's `revalidate`. Reads also carry a time limit (`CONTENT_REVALIDATE_SECONDS`, 5 minutes): tags make edits instant, the timer is what lets a scheduled post appear and a finished event drop out of "upcoming" with nobody touching the admin.
- Slug routes in the template (`/posts/[slug]`, `/events/[slug]`) implement `generateStaticParams` and **leave `dynamicParams` at its default `true`**, so a post created after the last deploy renders on first request. Setting it to `false` is a template lint error.
- No `export const dynamic = 'force-dynamic'` on content routes: a Neon scale-to-zero cold start would land on visitors.

---

## 5. Rich text

Stored as a **Tiptap (ProseMirror) JSON document** in `posts.body` and `events.description`. Never HTML.

Fixed node/mark set, shared by the editor (`@studio/core/admin`) and the renderer (`RichText`):

- nodes: `doc`, `text`, `paragraph`, `heading` (levels 2–3 only), `bulletList`, `orderedList`, `listItem`, `blockquote`, `hardBreak`, `image` (attrs: `mediaId`, `key`, `width`, `height`, `alt` — denormalised from the media row when inserted, so the renderer needs no database; rendered as a plain lazy `<img>` with explicit dimensions)
- marks: `bold`, `italic`, `link` (attrs: `href`, `rel="noopener"`, external `target="_blank"`)

The renderer **drops** any node or mark outside this set and any `href` that is not `http(s):`, `mailto:` or `tel:`. The editor is configured with exactly the same extensions so it cannot produce anything the renderer drops. `RichTextDoc` is validated by a zod schema on every admin write.

---

## 6. `Collection` config

The admin is generic. It is driven entirely by `defineCollection`; a collection with special-case UI code is a bug. Behaviour keys off configuration and field presence, never a collection name. The behaviour lives in core's hooks (`admin/hooks.ts`) and is what the tests cover; the screens are shadcn/ui components in the site (`components/admin`), so a site owns its admin UI the way it owns its sections, and a lifted backend can render its own.

- `label` / `labelSingular` are the owner's words (defaults: News/Post, Events, Photos/Photo, Messages, Donations) and are the only names the admin shows.
- `titleField` (default `title` when present) names a row; `dateField` (default `publishedAt`, `startsAt`, else `createdAt`) orders and dates it. A field with `format: 'money'` is integer cents shown in the row's `currency`. `defineCollection` derives `inbox` (has `readAt`) and `publishable` (draft/published `status`) once; the admin and the handlers read those flags rather than re-inferring the schema.
- `singleton: true` means exactly one row: `POST` refuses a second (409), `DELETE` is refused (405), the admin opens the form directly, and `content.get(name)` takes no id.
- `hidden` fields are server-managed: absent from the update schema entirely, and from the insert schema unless they carry a `default` the server applies. A client cannot address a media row's `key`, `mime`, `sizeBytes` or `confirmedAt`; media rows come only from `presign`.
- `view: 'grid'` lists rows as tiles with the `alt` description edited in place, multi-file and drag-and-drop upload, and a notice counting images with no description (the site's `check-site` blocks on empty alt). Default `'table'`.
- `publicPath: '/posts/:slug'` gives a row a public URL: "View on site" in the editor and a "View" action on the save toast, only when the row is published.
- A `status` select with `draft` and `published` (plus `publishedAt`) replaces the raw fields with a publish control: Publish / Save draft / Publish later… / Unpublish, with a "Scheduled" state when `publishedAt` is in the future. `slug` fields sit under an "Advanced" disclosure.
- A `readAt` field makes the collection an inbox: unread rows are bold, the nav shows an unread badge, opening a row marks it read, a row with an `email` gets a Reply (mailto) action, and `GET admin/[collection]` reports `unread` and accepts `?unread=1`.
- A `payload` object (form submissions) is shown as a message: who wrote it (the payload's `name`/`email`, the convention every public form in §2.2 follows), when, the longest field as the body, the rest as details.
- Constraint errors the schema cannot express (unique slug, check, not-null, bad uuid) are mapped in one place (`pgErrorToHttp`) to 400/404 with the offending field, never a 500.
- The publish rule is one function applied to the merged row on create and update: a row that ends up `published` with no `publishedAt` gets the current time; sending `publishedAt: null` on publish resets a scheduled date to "now".
- Every write reports its result in a toast. Navigation is internal (`pushState`), so the app and its toasts stay mounted across screens; the shell refuses to leave a form with unsaved edits and offers "Discard them" in the toast, and the browser warns on close. Delete confirms on a second click; there are no browser dialogs.

```ts
type FieldType = 'text' | 'textarea' | 'richtext' | 'image' | 'date' | 'datetime' | 'boolean' | 'select' | 'slug' | 'number'

type Field = {
  type: FieldType
  label?: string                         // default: humanised column name
  required?: boolean                     // default: column is NOT NULL and has no default
  help?: string
  options?: { value: string; label: string }[]   // select only
  from?: string                          // slug only: source field to derive from
  maxLength?: number
  hidden?: boolean                       // omitted from the form; system-managed or filled from `default`
  default?: unknown                      // applied on create when the form omits it (e.g. events.timezone from site config)
}

type CollectionConfig<T extends PgTable> = {
  table: T
  label: string                          // "Posts"
  labelSingular?: string                 // "Post"
  fields?: Partial<Record<keyof T['$inferInsert'], Partial<Field>>>   // overrides only
  list: {
    columns: (keyof T['$inferSelect'])[]
    sort: [keyof T['$inferSelect'], 'asc' | 'desc']
    search?: (keyof T['$inferSelect'])[]
  }
  readOnly?: boolean                     // list + view only; no create/update/delete
  view?: 'table' | 'grid'                // grid: tiles with in-place descriptions and drag-and-drop upload (files)
  publicPath?: string                    // '/posts/:slug' → "View on site" for published rows
  titleField?: string; dateField?: string // what names / dates a row (derived: title; publishedAt|startsAt|createdAt)
  singleton?: boolean                    // exactly one row (settings)
  reads?: { filter?, order?, filters? }  // public-read predicates; derived default is published rows, newest first
  schema?: (base: ZodObject) => ZodObject      // refinements on the derived schema
}
```

**Derivation rules** (so nothing is declared twice):

- Field defaults come from the Drizzle column: `text` → `text`; `text` named `excerpt`/`description`/`message` → `textarea`; `jsonb` → `richtext`; `uuid` FK to `media` → `image`; `timestamptz` → `datetime`; `date` → `date`; `boolean` → `boolean`; `integer`/numeric → `number`; column listed in `columnEnums` (kept beside the check constraints in `schema.ts`) → `select` with those options; column named `slug` → `slug` with `from: 'title'`. `required` = NOT NULL without a default.
- The insert/update zod schema is `drizzle-zod`'s `createInsertSchema(table)` with: `id`, `created_at`, `updated_at` omitted; `richtext` fields replaced by the `RichTextDoc` schema; `slug` fields refined to `/^[a-z0-9-]+$/`; `date`/`datetime` coerced from ISO strings; `image` fields validated as UUIDs; `maxLength` applied; every replacement re-wrapped with the column's own nullability/optionality; then `config.schema` refinements. Update = insert `.partial()`. The same schema validates the admin API, the admin form (client-side, via the JSON-serialised shape sent as `collectionsMeta`), and the template's seed script.
- The admin screens receive a **serialisable** `collections.meta` (no Drizzle objects) produced by `defineCollections`; the server side keeps the tables.

**The fixed set.** Core ships `defaultCollections({ timezone })`: `pages`, `posts`, `events`, `media`, `submissions` (readOnly), `donations` (readOnly), `settings` (singleton). `pages` are owner-made pages (title, body, cover, `showInNav`) served by the template at `/<slug>`; `settings` is the one row the header, footer and contact page read (name, tagline, email, phone, address, hours, socials), seeded from the brief by `db:seed` and then the owner's. `posts` and `events` carry an optional `category` (and events a free-text `cost`) so a list can be filtered with `content.list(name, { where: { category } })`. The template's `lib/collections.ts` calls `defineCollections(pickCollections(defaultCollections({ timezone }), enabled))` where `enabled` comes from `brief.json` features. The admin's publish rule is generic: any collection with a `publishedAt` field gets it set to now when `status` becomes `published` and it is empty. A site may **remove** collections; it may not add tables, fields, or field types. If a client needs a new field, that is a core release.

---

## 7. Environment contract — `env.ts`

A single zod schema, parsed at module load; failure throws listing **every** missing/invalid variable. This is the only place environment variables are read, and the pipeline imports the same schema to know what to set on a Vercel project.

| Variable | Required | Notes |
|---|---|---|
| `DATABASE_URL` | yes | Neon pooled, runtime |
| `DATABASE_URL_UNPOOLED` | yes | migrations only |
| `AUTH_SECRET` | yes | ≥ 32 bytes; generated by provision |
| `ADMIN_EMAILS` | yes | comma-separated, lowercased on parse |
| `NEXT_PUBLIC_SITE_URL` | yes | `https://…`, no trailing slash. `noindex` when its host ends with the studio domain |
| `RESEND_API_KEY` | yes | |
| `EMAIL_FROM` | yes | `Name <noreply@<studio-domain>>` |
| `EMAIL_REPLY_TO` | yes | the client's inbox |
| `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET` | yes | |
| `R2_PREFIX` | yes | `sites/<slug>` |
| `NEXT_PUBLIC_MEDIA_BASE_URL` | yes | `https://media.<studio-domain>` |
| `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | no (both or neither) | donations disabled when absent |
| `STUDIO_DOMAIN` | yes | the template's `app/robots.ts` disallows crawling while the site URL is under it |

`env.ts` also exports `envKeys` and `requiredEnvKeys` — the pipeline's provisioning code asserts it sets exactly `requiredEnvKeys` (plus the Stripe pair at go-live) and nothing else. `env` itself is a lazy proxy: importing the package never throws; the first property access parses `process.env`.

---

## 8. Non-goals

Written down so nobody — human or agent — "helpfully" adds them. Each is a deliberate refusal for v1.

- Multi-tenancy. One database per site.
- Roles. One admin role; the allowlist is the ACL.
- Public user accounts, registration, comments.
- Recurring events. Recurring donations / subscriptions.
- Page builder, block editor, or storing layout in the database. Pages live in the repo.
- Per-site custom collections, custom fields, or custom field types.
- i18n / multi-language.
- Theming from the database. Design lives in `direction.json` and tokens in the repo.
- Draft preview URLs (v1).
- Media beyond images and PDF; video is an embed link in rich text.
- A plugin or hook system; core is imported, not extended.
- Email templates beyond: magic link, form-submission notification, donation receipt.
- Auth providers other than magic link.
- Any dependency on Vercel-only APIs beyond `next/cache`. (Hosting could move.)

---

## 9. Contract tests

Each is a Vitest test in `packages/core/test/`, named after its section. Phase 1 is done when they pass.

| Test | Asserts |
|---|---|
| `01-exports` | `package.json#exports` has exactly `.`, `./admin`, `./next`, `./schema`, `./migrations`; resolving `@studio/core/db/schema` or any `src/` path throws |
| `02-schema` | every table has `id/created_at/updated_at`; `updated_at` changes on update; check constraints reject bad statuses; `media.key` and slugs are unique; FK `on delete set null` behaves |
| `03-migrations` | fresh Postgres (PGlite) → apply all migrations → `drizzle-kit/api` `pushSchema` reports zero statements (no drift); applying twice is a no-op; migrations from the oldest supported tag still apply cleanly forward |
| `04-revalidation` | each admin write calls `revalidateTag` with the collection's tags and the row tag (old and new slug on rename); `content.*` reads are wrapped with the declared tags |
| `05-richtext` | renderer output for a doc containing a disallowed node/mark/href omits it; editor extension list equals renderer allowlist |
| `06-collections` | every default collection derives its fields and zod schema from the table with no per-collection branch in `admin/`; each field type renders and validates; `readOnly` refuses writes; `collectionsMeta` is JSON-serialisable |
| `07-env` | missing required var throws listing all missing; optional Stripe pair must be both-or-neither; `envKeys` equals the table in §7 |
| `08-auth` | magic-link token is single-use and expires; sender rate-limits per email and per IP; verify sets a cookie whose HMAC validates against `AUTH_SECRET`; session delete revokes |
| `09-stripe` | webhook rejects a bad signature; the same `checkout.session.completed` twice yields one `donations` row; checkout returns 503 without Stripe env |
| `10-presign` | requires session; rejects disallowed mime, oversize, and keys outside `R2_PREFIX`; creates the media row with width/height |
| `11-forms` | each form validates its payload; honeypot rejects; rate limit; `email` extracted |
| `12-admin-format` | dates read like a person wrote them; labels, money, select options, publish state, repeat rules, and a message's who/body/details are derived from meta + row |
| `13-admin-writes` | publish transitions and the publish rule; constraint errors are 400/404; hidden columns are not writable; inbox read marks; the settings singleton; pages |
| `14-headless` | nothing outside `next.ts` imports `next`; `handle` serves the whole route table on Node's `http` |
| `15-events` | `occurrences` expands rules in the event's zone across DST and honours `UNTIL`; a bad rule shows the first date; the picker round-trips and reports custom rules; `.ics` output is valid; sign-ups land as `register` submissions |
| `16-admin-form` | `formBody`, `saveOutcome`, `duplicateBody`, `slugify` — the record form's rules without React |

Tests run against PGlite (in-process Postgres 17) so `pnpm test` needs no services. Production uses the Neon HTTP driver; both are Drizzle `PgDatabase` instances and the SQL is identical.

Template-side (in `template/`, run by `ci.yml`): ESLint fails on `@studio/core/<anything else>`; `dynamicParams = false` on a slug route fails lint; a fixture site builds and passes `check-site` with no model involved.
